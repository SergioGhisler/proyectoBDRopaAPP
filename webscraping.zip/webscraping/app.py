from flask import Flask, request,jsonify
from bs4 import BeautifulSoup
import requests
import random
app = Flask(__name__)


@app.route('/api',methods=['GET'])
def hello_world():
    Query =str(request.args['Query'])
    Query += ' women'
    url = 'https://www.asos.com/'
    search = 'search/?q=' + Query

    # Buscar
    link = url + search

    session = requests.Session()
    # me conecto a la pag
    page = session.get(link, headers={
        'User-Agent': 'Mozilla/5.0'})  # (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36'})
    soup = BeautifulSoup(page.content, 'html.parser')

    # prendas
    p = soup.find_all('div', class_='_3J74XsK')
    nombres = []
    print(link)
    for i in p:
        nombres.append(i.text)

    # precios
    e = soup.find_all('p', class_='_1ldzWib')
    precio = []
    for i in e:
        precio.append(i.text)

    # links
    l = [tag['href'] for tag in soup.find_all('a', {'class': "_3TqU78D"})]
    enlaces = []
    for i in l:
        enlaces.append(i)

    # Creo las listas para meter los 4 ejemplos que va a mostrar

    # Funcion para buscar caracteres en strings
    def findOccurrences(s, ch):
        return [i for i, letter in enumerate(s) if letter == ch]

    links = []
    prendas = []
    precios_prendas = []
    count = 0
    while count < 4:
        r = random.randint(0, len(nombres) - 1)
        prendas.append(nombres[r])

        # print(precio[count])

        a = findOccurrences(precio[r], " ")
        # print(a)
        if a == []:
            precio_final = precio[r]
        else:
            precio_final = precio[r][a[-1] + 1:]
        # print(precio_final)
        precios_prendas.append(precio_final)
        links.append(enlaces[r])
        count += 1

    # lo imprimo en un dataframe para comprobar
    '''
    df = pd.DataFrame({'Nombre':prendas, 'precio':precios_prendas,'Links':links}, index=list(range(1,5)))
    print(df)
    '''

    # borrar($S$)
    def borrar(b):
        c = b.find('$S$')
        b = b[:c]
        b = b + '$XXL$'
        return b

    # Segundo Scraping
    fotos = []
    count = 0
    while count < 4:
        link2 = links[count]
        # print(link2)
        page2 = session.get(link2, headers={'User-Agent': 'Mozilla/5.0'})
        soup2 = BeautifulSoup(page2.content, 'html.parser')
        # images = soup2.find('img').get('src')
        # images = soup2.findAll('img')[1:]#<img alt="Thumbnail 1 of 4" src="https://images.asos-media.com/products/asos-design-high-waist-trousers-skinny-fit/13091172-1-navy?$S$&amp;wid=40&amp;fit=constrain"/>
        # print(images)
        aux = []
        image1 = soup2.find('img', {'alt': 'Thumbnail 1 of 4'})['src']
        aux.append(borrar(image1))
        image2 = soup2.find('img', {'alt': 'Thumbnail 2 of 4'})['src']
        aux.append(borrar(image2))
        image3 = soup2.find('img', {'alt': 'Thumbnail 3 of 4'})['src']
        aux.append(borrar(image3))
        image4 = soup2.find('img', {'alt': 'Thumbnail 4 of 4'})['src']
        aux.append(borrar(image4))

        fotos.append(aux)
        count += 1

    # Creo el json con los 4 ejemplos de muestra
    result = {}
    result['items'] = []

    result['items'].append({
        'link': links[0],
        'nombre': prendas[0],
        'precio': precios_prendas[0],
        'photo': fotos[0][0],
        'todas las fotos': [fotos[0][0], fotos[0][1], fotos[0][2], fotos[0][3]]})

    result['items'].append({
        'link': links[1],
        'nombre': prendas[1],
        'precio': precios_prendas[1],
        'photo': fotos[1][0],
        'todas las fotos': [fotos[1][0], fotos[1][1], fotos[1][2], fotos[1][3]]})

    result['items'].append({
        'link': links[2],
        'nombre': prendas[2],
        'precio': precios_prendas[2],
        'photo': fotos[2][0],
        'todas las fotos': [fotos[2][0], fotos[2][1], fotos[2][2], fotos[2][3]]})

    result['items'].append({
        'link': links[3],
        'nombre': prendas[3],
        'precio': precios_prendas[3],
        'photo': fotos[3][0],
        'todas las fotos': [fotos[3][0], fotos[3][1], fotos[3][2], fotos[3][3]]})
    jsonify(result)
    return result

if __name__ == '__main__':
    app.run()
